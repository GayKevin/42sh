#ifndef MY_PUT_TOOL_H_
# define MY_PUT_TOOL_H_


void	my_putchar(char c);
void	my_putstr(char *str);
void	my_put_nbr(int nb);
int     my_strlen(char *str);

#endif /* MY_PUT_TOOL */
