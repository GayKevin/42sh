/*
** my_free.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 11:47:36 2014 Maxime Limone
** Last update Mon May  5 11:47:36 2014 Maxime Limone
*/

#ifndef MY_FREE_H_
# define MY_FREE_H_

void	my_free(char **str);

#endif /* MY_FREE */
