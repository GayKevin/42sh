/*
** ps1.h for ps1$ in /home/gay_k/rendu/42sh
** 
** Made by Kevin Gay
** Login   <gay_k@epitech.net>
** 
** Started on  Wed May 14 02:24:13 2014 Kevin Gay
** Last update Wed May 14 02:32:00 2014 Kevin Gay
*/

#ifndef PS1_H_
# define PS1_H_

int	*find_ps1(t_shell *sh);

#endif /* SHELL_H_ */
