/*
** env.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 11:45:08 2014 Maxime Limone
** Last update Mon May  5 11:45:09 2014 Maxime Limone
*/

#ifndef ENV_H_
# define ENV_H_

int	get_env(t_shell *sh, char **env);

#endif /* ENV */
