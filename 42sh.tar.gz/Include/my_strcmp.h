#ifndef MY_STRCMP_H_
# define MY_STRCMP_H_

int	my_strcmp_(char *str1, char *str2);
int	my_strcmp(char *str1, char *str2);
int	my_strcmp_nbr(char *str1, char *str2, int o);

#endif /* MY_STRCMP */
