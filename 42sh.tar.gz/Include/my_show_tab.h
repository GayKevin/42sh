/*
** my_show_tab.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 14:51:10 2014 Maxime Limone
** Last update Mon May  5 14:51:11 2014 Maxime Limone
*/

#ifndef MY_SHOW_TAB_H_
# define MY_SHOW_TAB_H_

void    my_show_tab(char **tab);

#endif /* MY_SHOW_TAB */
