/*
** unsetenv.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 14:50:41 2014 Maxime Limone
** Last update Mon May  5 14:50:45 2014 Maxime Limone
*/

#ifndef UNSETENV_H_
# define UNSETENV_H

int	unset_env(t_shell *sh, int i);

#endif /* UNSETENV */
