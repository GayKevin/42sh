/*
** my_printf_error.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 11:48:52 2014 Maxime Limone
** Last update Mon May  5 11:48:53 2014 Maxime Limone
*/

#ifndef MY_PRINTF_ERROR_H_
# define MY_PRINTF_ERROR_H_

int	printf_error(const char *format, ...);

#endif /* MY_PRINTF_ERROR */
