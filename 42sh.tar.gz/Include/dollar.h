/*
** dollar.h for dollar in /home/gay_k/42sh
** 
** Made by Kevin Gay
** Login   <gay_k@epitech.net>
** 
** Started on  Tue May 13 13:43:30 2014 Kevin Gay
** Last update Wed May 14 02:13:14 2014 Kevin Gay
*/

#ifndef DOLLAR_H_
# define DOLLAR_H_

int	dollar(t_shell *sh);
int	compare_env_dollar(char *tmp, t_shell *sh, int p);

#endif /* DOLLAR */
