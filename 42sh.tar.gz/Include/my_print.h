#ifndef MY_PRINTF_H_
# define MY_PRINTF_H

int	printf_error(const char *format, ...);

#endif /* MY_PRINTF */
