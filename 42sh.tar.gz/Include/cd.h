/*
** cd.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 11:44:42 2014 Maxime Limone
** Last update Mon May  5 11:44:43 2014 Maxime Limone
*/

#ifndef CD_H_
# define CD_H_

int	find_cd(t_shell *sh, int i);

#endif /* CD */

