/*
** built_in.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 11:43:23 2014 Maxime Limone
** Last update Mon May  5 11:43:24 2014 Maxime Limone
*/

#ifndef BUILT_IN_H_
# define BUILT_IN_H_

int	built_in(t_shell *sh);

#endif /* BUILT_IN */
