#ifndef STRUCT_H_
# define STRUCT_H_

int	my_getnbr(char *str);

#endif /* MY_GETNBR */
