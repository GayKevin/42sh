/*
** my_malloc_pwd.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 11:48:26 2014 Maxime Limone
** Last update Mon May  5 11:48:27 2014 Maxime Limone
*/

#ifndef  MY_MALLOC_PWD_H_
# define  MY_MALLOC_PWD_H_

int	my_malloc_pwd(t_shell *sh, int d, char *cmd);

#endif /* MY_MALLOC_PWD */
