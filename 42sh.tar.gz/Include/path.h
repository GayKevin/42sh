/*
** path.h for 42sh in /home/limone_m/rendu/PSU_2013_42sh/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Mon May  5 14:47:58 2014 Maxime Limone
** Last update Mon May  5 14:47:59 2014 Maxime Limone
*/

#ifndef PATH_H_
# define PATH_H_

int	path(t_shell *sh, char *env);
int	find_path(t_shell *sh);

#endif /* PATH */
