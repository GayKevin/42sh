/*
** my_putstr.h for my_putstr in /home/gay_k/42sh
** 
** Made by Kevin Gay
** Login   <gay_k@epitech.net>
** 
** Started on  Tue May 13 14:38:58 2014 Kevin Gay
** Last update Tue May 13 14:39:53 2014 Kevin Gay
*/

#ifndef  MY_PUTSTR_H_
# define  MY_PUTSTR_H_

char	*my_putstr(char *str);

#endif /* MY_STRCAT */
