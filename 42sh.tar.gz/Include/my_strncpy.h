/*
** my_strncpy.h for strncpyu in /home/gay_k/42sh
** 
** Made by Kevin Gay
** Login   <gay_k@epitech.net>
** 
** Started on  Tue May 13 13:46:23 2014 Kevin Gay
** Last update Tue May 13 13:46:25 2014 Kevin Gay
*/

#ifndef MY_STRNCPY_H_
# define MY_STRNCPY_H_

char    *my_strncpy(char *dest, char *src, int i);

#endif /* MY_STRCPY */
