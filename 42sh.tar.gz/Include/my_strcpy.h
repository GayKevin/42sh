#ifndef MY_STRCPY_H_
# define MY_STRCPY_H_

char    *my_strcpy(char *dest, char *src);

#endif /* MY_STRCPY */
