/*
** epur_str.h for 42sh in /home/limone_m/rendu/42sh
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Sun May 11 16:53:08 2014 Maxime Limone
** Last update Sun May 11 16:54:45 2014 Maxime Limone
*/

#ifndef EPUR_STR_H_
# define EPUR_STR_H_

char		*clean_str(char *str, int size);
char		*epur_str(char *str);

#endif /* EPUR_STR_H_ */
