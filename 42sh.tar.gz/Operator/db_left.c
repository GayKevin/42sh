/*
** db_left.c for left in /home/gay_k/42sh
** 
** Made by Kevin Gay
** Login   <gay_k@epitech.net>
** 
** Started on  Tue May 13 22:40:16 2014 Kevin Gay
** Last update Tue May 13 23:28:47 2014 Kevin Gay
*/

#include "main.h"
#include "tree.h"

int	db_left(t_node *tree, t_shell *sh)
{
  return (0);
}
